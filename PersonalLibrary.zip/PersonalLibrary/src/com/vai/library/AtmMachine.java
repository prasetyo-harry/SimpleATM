package com.vai.library;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AtmMachine {

    private static Scanner in ;
	static String userName;
	static Integer pinNumber;
    private static float balance = 0;
    private static int anotherTransaction;
    static DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
    
    public static void main(String args[]) {
        in = new Scanner(System.in);
        introduction();
        getLogin();
    }
    
	public static void introduction() {
		System.out.println(" _____________________Syariah ATM Company_______________________");			
		System.out.print("|\t\t\t\t\t\t\t\t|\n");			
		System.out.printf("|\t\t    Welcome to %s\t\t\t|\n", "Syariah Bank");
		System.out.print("|\t\t\t\t\t\t\t\t|\n");
		System.out.println("|_______________________________________________________________|");
		System.out.println("|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|");
		System.out.println("|_______________________________________________________________|");
	}

	public static void getLogin(){
		boolean end = false;

		while (!end) {
			try {
				System.out.print("|XXXXXXXXXXXXXXXXXXXXXXXXX LOGIN XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|");
				System.out.print("\n Enter your Username: ");
				userName = in.next();
				System.out.print("\n Enter your PIN number: ");
				pinNumber = in.nextInt();
					if ("alice".equals(userName) && pinNumber == 1111) {
						System.out.println("|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|");
						System.out.println(" 																 ");
						System.out.print(" Hello, "+userName);
						transaction();
						end = true;
						break;
					}
					if("bob".equals(userName) && pinNumber == 2222){
						System.out.println("|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|");
						System.out.println(" 																 ");
						System.out.print(" Hello, "+userName);
						transaction();
						end = true;
						break;
					}else{
						System.out.println("\n Wrong Username or Pin Number");
						end = false;
					}
			} catch (InputMismatchException e) {
				System.out.println("\n Invalid Character(s). Only Numbers.");
			}
		}
	}
	
    private static void transaction() {
        Integer choice;
        System.out.println("\n Please select an option :");
        System.out.println(" 1. Withdraw");
        System.out.println(" 2. Deposit");
        System.out.println(" 3. Balance");
        System.out.println(" 4. Transfer");
        System.out.println("\n Choice :");
        
        choice = in .nextInt();

        switch (choice) {
            case 1:
                float amount;
                System.out.println("\n Please enter amount to withdraw: ");
                amount = in .nextFloat();
                if (amount > balance || amount == 0) {
                    System.out.println("\n You have insufficient funds\n\n");
                    anotherTransaction();
                } else {
                    balance = balance < 0 ? -balance : balance - amount;
                    System.out.println("\n You have withdrawn " + moneyFormat.format(amount) + " and your new balance is " + moneyFormat.format(balance) + "\n");
                    anotherTransaction();
                }
                break;

            case 2:
                float deposit;
                System.out.println("\n Please enter amount you would wish to deposit: ");
                deposit = in .nextFloat();
                balance = deposit + balance;
                System.out.println("\n You have deposited " + moneyFormat.format(deposit) + " new balance is " + moneyFormat.format(balance) + "\n");
                anotherTransaction();
                break;

            case 3:
                System.out.println("\n Your balance is " + moneyFormat.format(balance < 0 ? -balance : balance));
                anotherTransaction();
                break;
            case 4:
                float transfer;
                String personTransfer;
                System.out.println("\n Please enter amount you want to transfer: ");
                transfer = in.nextFloat();
                System.out.println("\n Person to transfer the money: ");
                personTransfer= in.next();
                balance = balance < 0 ? -balance : balance - transfer;
                if( balance < 0){
                	System.out.println("\n You have transfer "+" "+moneyFormat.format(transfer)+" "+"to "+ personTransfer + " and your new balance is " + moneyFormat.format(balance < 0? 0 : balance)+ "\n");
                	System.out.println("\n Owed"+" "+moneyFormat.format(balance * -1)+" "+ "to "+personTransfer);
                	anotherTransaction();
                }else{
                	System.out.println("\n You have transfer"+" "+ moneyFormat.format(transfer)+" "+"to "+ personTransfer + " and your new balance is " + moneyFormat.format(balance) + "\n");
                	anotherTransaction();
                }
                break;
                

            default:
                System.out.println(" Invalid option:\n\n");
                anotherTransaction();
                break;
        }

    }

    private static void anotherTransaction() {
        System.out.println("\n Do you want another transaction?\n Press 1 for another transaction\n Press 2 To exit");
        anotherTransaction = in .nextInt();
        if (anotherTransaction == 1) {
            transaction();
        } else if (anotherTransaction == 2) {
            System.out.println("\n Thanks for choosing us. Good Bye"+" "+userName+"!");
            System.out.println("                                                    ");
            introduction();
            getLogin();
        } else {
            System.out.println("\n Invalid choice\n\n");
            anotherTransaction();
        }
    }
}
